//: [Previous](@previous)
//:# Game —— Hard Version
import PlaygroundSupport
import SpriteKit
//:
//: Do you think the easy version is too easy? Here is a really hard one.
//:
//: The hard version of the game simulates the senario, in which no assisted control is provided. You have to manually adjust the lift each rotor provides, similar to that of [Physics](Physics) part.
/*:
 J: increase lift on right rotor, hold to increase more
 
 K: decrease lift on right rotor, hold to decrease more
 
 F: increase lift on left rotor, hold to increase more
 
 D: decrease lift on left rotor, hold to decrease mroe
 
 L: increase lift on both right rotor and left rotor, hold to increase more
 
 S: decrease lift on both right rotor and left rotor, hold to decrease more
 
 H: load pakage
 
 Space Bar: drop pakage
 */
//: Good luck! Enjoy the game!
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
if let scene = HardGame(fileNamed: "Background") {
    scene.scaleMode = .aspectFill
    sceneView.presentScene(scene)
}

sceneView.showsFPS = true
sceneView.showsNodeCount = true

PlaygroundPage.current.liveView = sceneView

