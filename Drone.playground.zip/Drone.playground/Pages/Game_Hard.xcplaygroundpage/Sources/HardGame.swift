import SpriteKit
import AVFoundation

public class HardGame: SKScene {
    
    let body = SKSpriteNode(imageNamed: "body")     // Drone body
    let rotorL = SKSpriteNode(imageNamed: "Lrotor") // Left rotor
    let rotorR = SKSpriteNode(imageNamed: "Rrotor") // Right rotor
    
    let smallSignal = SKSpriteNode(imageNamed: "small")
    let midSignal = SKSpriteNode(imageNamed: "mid")
    let largeSignal = SKSpriteNode(imageNamed: "large")
    
    let stick = SKShapeNode(rectOf: CGSize(width: 60, height: 45))
    
    let liftL = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let liftR = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    
    var box: SKSpriteNode!
    var arrow: SKSpriteNode? = nil
    
    let boxes = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let toWho = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    
    let labelAlice = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelBob = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelJohnny = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelJane = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelEve = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelTrent = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelMallory = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    
    public var mass: Double = 10.0
    public var fL = CGFloat(5*9.8*30)   // Lift of the left rotor
    public var fR = CGFloat(5*9.8*30)   // Lift of the right rotor
    var pos = CGPoint(x: 0.0, y: 0.0)   // Position of drone body
    var pL = CGPoint(x: 0.0, y: 0.0)    // Position of left rotor
    var pR = CGPoint(x: 0.0, y: 0.0)    // Position of right rotor
    var vL = CGVector(dx: 0.0, dy: 0.0) // Velocity of left rotor
    var vR = CGVector(dx: 0.0, dy: 0.0) // Velocity of right rotor
    var rotation = CGFloat(0.0)
    
    // 30 pixels = 1 meter. SpriteKit default ratio 150 pixels = 1 meter. 30/150 = 1/5
    let ratio = 1.0/5.0
    
    let cameraNode = SKCameraNode()
    
    let zero = SKRange(constantValue: 0)
    let ninetyDegree = SKRange(constantValue: -CGFloat.pi/2)
    let positive90 = SKRange(constantValue: CGFloat.pi/2)
    
    // Time
    var t = 0.0
    var dt = 0.5
    var sinceKeyPressed = 0.0
    var afterLoad = 0.0
    
    var keyStroke: Int? = nil
    var multiplier = CGFloat(0.0)
    
    var start = 0.0
    
    // Check if the box is delivered
    var delivered = true
    var deliveredToMallory = false
    var deliveredToJane = false
    
    let ball = SKShapeNode(circleOfRadius: 10)

    public override func didMove(to view: SKView) {
        let background = childNode(withName: "background") as! SKSpriteNode
        background.physicsBody = SKPhysicsBody(edgeLoopFrom: background.frame)
        
        drone()
        cameraSetup()
        tower()
        labels()
        
        physicsWorld.contactDelegate = self
        
        arrow = childNode(withName: "arrow") as? SKSpriteNode
        if let a = arrow {
            a.alpha = 0.0
            a.setScale(0.6)
            a.position = CGPoint(x: 0, y: 0)
            let arrowLocation = SKConstraint.distance(zero, to: body)
            a.constraints = [arrowLocation]
        }
    }
    
    func load() {
        box = SKSpriteNode(imageNamed: "box")
        box.position = CGPoint(x: -188, y: -50)
        addChild(box)
        afterLoad = t
        let xBox = SKAction.move(by: CGVector(dx: 112+188, dy: 0), duration: 2)
        let yBox = SKAction.move(by: CGVector(dx: 0, dy: -75), duration: 1)
        let boxFadeOut = SKAction.fadeOut(withDuration: 1)
        let yGroup = SKAction.group([yBox, boxFadeOut])
        let motion = SKAction.sequence([xBox, yGroup])
        box.run(motion)
    }
    
    func drone() {
        body.position = CGPoint(x: 115, y: -92)
        body.anchorPoint = CGPoint(x: 0.47979798, y: 0.59574468)
        rotorL.anchorPoint = CGPoint(x: 0.207070, y: 0.8617)
        rotorR.anchorPoint = CGPoint(x: 0.752525, y: 0.8617)
        rotorL.position = CGPoint(x: body.frame.midX-29, y: body.frame.midY+17)
        rotorR.position = CGPoint(x: body.frame.midX+25, y: body.frame.midY+17)
        
        body.name = "drone"
        rotorR.name = "drone"
        rotorL.name = "drone"
        
        body.physicsBody = SKPhysicsBody(texture: body.texture!, size: body.texture!.size())
        rotorL.physicsBody = SKPhysicsBody(texture: rotorL.texture!, size: rotorL.texture!.size())
        rotorR.physicsBody = SKPhysicsBody(texture: rotorR.texture!, size: rotorR.texture!.size())
        
        body.physicsBody?.categoryBitMask = 0b0001
        rotorR.physicsBody?.categoryBitMask = 0b0010
        rotorL.physicsBody?.categoryBitMask = 0b0010
        body.physicsBody?.contactTestBitMask = 0b1000
        //rotorR.physicsBody?.contactTestBitMask = 0b1000
        //rotorL.physicsBody?.contactTestBitMask = 0b1000
        
        body.physicsBody?.mass = 0.0
        rotorL.physicsBody?.mass = 0.0
        rotorR.physicsBody?.mass = 0.0
        
        body.physicsBody?.affectedByGravity = false
        rotorL.physicsBody?.affectedByGravity = false
        rotorR.physicsBody?.affectedByGravity = false
        
        stick.position = CGPoint(x: body.frame.midX-2, y: body.frame.midY+4.5)
        stick.alpha = 0.0
        stick.name = "stick"
        stick.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 60, height: 45))
        stick.physicsBody?.mass = CGFloat(mass*ratio)
        stick.physicsBody?.friction = 0.9
        stick.physicsBody?.restitution = 0.05
        stick.physicsBody?.isDynamic = false
        stick.physicsBody?.categoryBitMask = 0b0010
        stick.physicsBody?.collisionBitMask = 0b0100
        
        addChild(body)
        addChild(rotorR)
        addChild(rotorL)
        addChild(stick)
        
        let locationBody = SKConstraint.distance(zero, to: stick)
        let locationR = SKConstraint.distance(zero, to: CGPoint(x: 27, y: 12), in: stick)
        let locationL = SKConstraint.distance(zero, to: CGPoint(x: -27, y: 12), in: stick)
        let rotationBody = SKConstraint.orient(to: CGPoint(x: 0, y: 2), in: stick, offset: ninetyDegree)
        let rotationR = SKConstraint.orient(to: CGPoint(x: 27, y: 0), in: stick, offset: ninetyDegree)
        let rotationL = SKConstraint.orient(to: CGPoint(x: -27, y: 0), in: stick, offset: ninetyDegree)
        body.constraints = [locationBody, rotationBody]
        rotorL.constraints = [locationL, rotationL]
        rotorR.constraints = [locationR, rotationR]
        
        toWho.fontSize = 16
        toWho.fontColor = .darkGray
        toWho.position = CGPoint(x: 0, y: 20)
        toWho.text = ""
        body.addChild(toWho)
    }
    
    func cameraSetup() {
        camera = cameraNode
        addChild(cameraNode)
        let range = SKRange(lowerLimit: 0, upperLimit: 250)
        let constraint1 = SKConstraint.distance(range, to: stick)
        let constranit2 = SKConstraint.positionY(SKRange(lowerLimit: -210, upperLimit: 210))
        let constraint3 = SKConstraint.positionX(SKRange(lowerLimit: -2500, upperLimit: 2500))
        cameraNode.constraints = [constraint1, constranit2, constraint3]
        
        liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
        liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
        liftL.fontSize = 20
        liftR.fontSize = 20
        liftL.fontColor = .darkGray
        liftR.fontColor = .darkGray
        camera?.addChild(liftL)
        camera?.addChild(liftR)
        liftL.position = CGPoint(x: -150, y: -375)
        liftR.position = CGPoint(x: 150, y: -375)
        
        boxes.text = "Boxes delivered: 0 / 2"
        boxes.fontSize = 22
        boxes.position = CGPoint(x: 280, y: 340)
        boxes.fontColor = .orange
        camera?.addChild(boxes)
    }

    func tower() {
        smallSignal.position = CGPoint(x: -2010, y: -285)
        midSignal.position = CGPoint(x: -2010, y: -285)
        largeSignal.position = CGPoint(x: -2010, y: -285)
        smallSignal.alpha = 0.0
        midSignal.alpha = 0.0
        largeSignal.alpha = 0.0
        let fadeInS = SKAction.fadeIn(withDuration: 0.5)
        let fadeOutS = SKAction.fadeOut(withDuration: 1.5)
        let fadeInM = SKAction.fadeIn(withDuration: 1.0)
        let fadeOutM = SKAction.fadeOut(withDuration: 1.0)
        let fadeInL = SKAction.fadeIn(withDuration: 1.5)
        let fadeOutL = SKAction.fadeOut(withDuration: 0.5)
        let sequenceS = SKAction.sequence([fadeInS, fadeOutS])
        let sequenceM = SKAction.sequence([fadeInM, fadeOutM])
        let sequenceL = SKAction.sequence([fadeInL, fadeOutL])
        smallSignal.run(.repeatForever(sequenceS))
        midSignal.run(.repeatForever(sequenceM))
        largeSignal.run(.repeatForever(sequenceL))
        
        addChild(smallSignal)
        addChild(midSignal)
        addChild(largeSignal)
    }
    
    func labels() {
        labelAlice.position = CGPoint(x: -2260, y: -220)
        labelEve.position = CGPoint(x: -1745, y: -250)
        labelTrent.position = CGPoint(x: -1470, y: -340)
        labelMallory.position = CGPoint(x: 1070, y: -215)
        labelJane.position = CGPoint(x: 1700, y: -300)
        labelJohnny.position = CGPoint(x: 2275, y: -300)
        labelBob.position = CGPoint(x: 2585, y: -300)
        labelAlice.text = "Alice"
        labelBob.text = "Bob"
        labelJohnny.text = "Johnny"
        labelJane.text = "Jane"
        labelMallory.text = "Malllory"
        labelEve.text = "Eve"
        labelTrent.text = "Trent"
        labelAlice.fontSize = 18
        labelBob.fontSize = 18
        labelEve.fontSize = 18
        labelJane.fontSize = 18
        labelJohnny.fontSize = 18
        labelMallory.fontSize = 18
        labelTrent.fontSize = 18
        addChild(labelAlice)
        addChild(labelBob)
        addChild(labelEve)
        addChild(labelJane)
        addChild(labelJohnny)
        addChild(labelMallory)
        addChild(labelTrent)
    }
    
    func boxPhysicsBody() {
        box.physicsBody = SKPhysicsBody(texture: box.texture!, size: box.texture!.size())
        box.physicsBody?.linearDamping = 5
        box.physicsBody?.mass = CGFloat(2.0*ratio)
        if !deliveredToMallory {
            box.physicsBody?.categoryBitMask = 0x1 << 11
            box.physicsBody?.collisionBitMask = 0b10111111
            box.physicsBody?.contactTestBitMask = 0x1 << 6
        } else {
            box.physicsBody?.categoryBitMask = 0x1 << 12
            box.physicsBody?.collisionBitMask = 0b01111111
            box.physicsBody?.contactTestBitMask = 0x1 << 7
        }
    }

    func force() {
        // 27 is the distance between the center of the body and where the lift is applied on the body
        pL = CGPoint(x: pos.x-27*cos(rotation), y: pos.y-27*sin(rotation))
        pR = CGPoint(x: pos.x+27*cos(rotation), y: pos.y+27*sin(rotation))
        vL = CGVector(dx: -fL*sin(rotation), dy: fL*cos(rotation))
        vR = CGVector(dx: -fR*sin(rotation), dy: fR*cos(rotation))
        stick.physicsBody?.applyForce(vL, at: pL)
        stick.physicsBody?.applyForce(vR, at: pR)
    }
    
    public override func mouseDown(with event: NSEvent) {
        stick.physicsBody?.isDynamic = true
        
        let negative = SKAction.scaleX(to: -1.0, duration: 0.08)
        let positive = SKAction.scaleX(to: 1.0, duration: 0.08)
        let sequence1 = SKAction.sequence([negative, positive])
        let sequence2 = SKAction.sequence([positive, negative])
        
        // Two rotors need to spin in opposite direction to counter torque
        rotorL.run(.repeatForever(sequence1))
        rotorR.run(.repeatForever(sequence2))
    }
    
    public override func keyDown(with event: NSEvent) {
        if event.keyCode == 35 { stick.physicsBody?.isDynamic = false }
        if event.keyCode == 3 {
            fL += 0.01*30
            liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
            keyStroke = 3
        }
        if event.keyCode == 38 {
            fR += 0.01*30
            liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
            keyStroke = 38
        }
        if event.keyCode == 2 {
            fL -= 0.01*30
            liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
            keyStroke = 2
        }
        if event.keyCode == 40 {
            fR -= 0.01*30
            liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
            keyStroke = 40
        }
        if event.keyCode == 1 {
            fR -= 0.01*30
            fL -= 0.01*30
            liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
            liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
            keyStroke = 1
        }
        if event.keyCode == 37 {
            fR += 0.01*30
            fL += 0.01*30
            liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
            liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
            keyStroke = 37
        }
        if event.keyCode == 49 {
            box.run(SKAction.fadeIn(withDuration: 0.3))
            box.constraints = []
            boxPhysicsBody()
            boxes.text = "Empty"
        }
        if event.keyCode == 4 { // h
            if delivered {
                let Xbody = body.position.x
                let Ybody = body.position.y
                if Xbody > 75 && Xbody < 175 && Ybody < -60 && Ybody > -100 {
                    load()
                    body.physicsBody?.isDynamic = false
                } else {
                    print("out of loading range")
                }
            } else {
                print("deliver the current box before reloading!")
            }
        }
        start = t
    }
    
    
    public override func keyUp(with event: NSEvent) {
        start = 0.0
        keyStroke = nil
    }
    
    
    public override func update(_ currentTime: TimeInterval) {
        t = currentTime
        if stick.physicsBody!.isDynamic {
            pos = stick.position
            rotation = stick.zRotation
            force()
        }
        if start != 0.0 {
            if t-start > 0.1 {
                multiplier = CGFloat(((t-start-0.1)/dt).rounded())
                if keyStroke == 3 {
                    fL += 0.01*30*multiplier
                    liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
                }
                if keyStroke == 38 {
                    fR += 0.01*30*multiplier
                    liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
                }
                if keyStroke == 2 {
                    fL -= 0.01*30*multiplier
                    liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
                }
                if keyStroke == 40 {
                    fR -= 0.01*30*multiplier
                    liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
                }
                if keyStroke == 1 {
                    fR -= 0.01*30*multiplier
                    fL -= 0.01*30*multiplier
                    liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
                    liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
                }
                if keyStroke == 37 {
                    fR += 0.01*30*multiplier
                    fL += 0.01*30*multiplier
                    liftR.text = "Lift on right side: \((fR/30*100).rounded()/100) N"
                    liftL.text = "Lift on left side: \((fL/30*100).rounded()/100) N"
                }
            }
        }
        if afterLoad != 0.0 {
            if t-afterLoad > 2 {
                let constraint = SKConstraint.distance(zero, to: CGPoint(x: 0, y: -30), in: body)
                box.constraints = [constraint]
                delivered = false
                afterLoad = 0.0
                
                body.physicsBody?.isDynamic = true
                
                if let a = arrow {
                    a.alpha = 1.0
                    if !deliveredToMallory {
                        toWho.text = "To: Mallory  Loaded"
                        let arrowAngle = SKConstraint.orient(to: labelMallory, offset: positive90)
                        a.constraints?.append(arrowAngle)
                    } else {
                        toWho.text = "To: Jane  Loaded"
                        let arrowAngle = SKConstraint.orient(to: labelJane, offset: positive90)
                        a.constraints?.append(arrowAngle)
                    }
                }
            }
        }
    }
}

extension HardGame: SKPhysicsContactDelegate {
    func deliver() {
        let fade = SKAction.fadeOut(withDuration: 1)
        let fadeAndRemove = SKAction.sequence([fade, .removeFromParent()])
        box.run(fadeAndRemove)
        toWho.text = ""
    }
    public func didBegin(_ contact: SKPhysicsContact) {
        let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        if contactMask == 0b100001000000 {
            delivered = true
            deliveredToMallory = true
            deliver()
            boxes.text = "Boxes Delivered: 1 / 2"
            if let a = arrow { a.alpha = 0.0 }
        }
        if contactMask == 0b1000010000000 {
            delivered = true
            deliveredToJane = true
            deliver()
            boxes.text = "Boxes Delivered: 2 / 2"
            if let a = arrow { a.alpha = 0.0 }
            let congradulation = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
            congradulation.text = "WOW! YOU ACCOMPLISHED HARD LEVEL"
            congradulation.fontSize = 48
            congradulation.position = CGPoint(x: frame.midX, y: frame.midY)
            camera?.addChild(congradulation)
            self.run(SKAction.playSoundFileNamed("tada.aif", waitForCompletion: false))
        }
        
        if contact.collisionImpulse > 75 {
            print(contact.collisionImpulse)
            if contact.bodyA.node?.name == "drone" || contact.bodyB.node?.name == "drone" {
                if contact.bodyA.node?.name == "signalTower" || contact.bodyB.node?.name == "signalTower" {
                    self.run(SKAction.playSoundFileNamed("ding.aif", waitForCompletion: false))
                } else {
                    self.run(SKAction.playSoundFileNamed("hitting.aif", waitForCompletion: false))
                }
            }
        }
    }
}
