//: [Previous](@previous)
//:# Game —— Easy Version
//:
import PlaygroundSupport
import SpriteKit
//:
//: In reality, the control of the drone is mostly by algorithm, which includes all the calculation we've done in the physics part.
//: The easy version of the game is similar to flying a drone in real world. You control joystick to give command to the drone and the drone will smoothly follow your instruction.
//:
//: In the easy version of the game, the joystick is the W,A,S,D keys on the keyboard.
//:
//:## Click game window to start the game
/*:
 W: move upward, hold to accelerate more
 
 S: move downward, hold to accelerate more
 
 A: move leftward, hold to accelerate more
 
 D: move rightward, hold to accelerate more
 */
//: Only one key can be registered at a time!
//:
//: Let's deliver some pakages by using drone!
/*:
 L: load the pakage
 
 Space Bar: drop the pakage
 */
//:
//: After delivering one pakage, return the the station platform to reload another pakage
//:
//: Enjoy!

//: To play harder version, click Game_Hard below
//:
//: [Game_Hard](@next)
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "Background") {
    scene.scaleMode = .aspectFill
    sceneView.presentScene(scene)
}

sceneView.showsFPS = true
sceneView.showsNodeCount = true

PlaygroundPage.current.liveView = sceneView

