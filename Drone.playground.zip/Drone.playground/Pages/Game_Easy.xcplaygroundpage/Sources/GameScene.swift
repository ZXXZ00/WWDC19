import SpriteKit
import AVFoundation

public class GameScene: SKScene {
    
    let body = SKSpriteNode(imageNamed: "body")     // Drone body
    let rotorL = SKSpriteNode(imageNamed: "Lrotor") // Left rotor
    let rotorR = SKSpriteNode(imageNamed: "Rrotor") // Right rotor
    
    let smallSignal = SKSpriteNode(imageNamed: "small")
    let midSignal = SKSpriteNode(imageNamed: "mid")
    let largeSignal = SKSpriteNode(imageNamed: "large")
    
    var box: SKSpriteNode!
    var arrow: SKSpriteNode? = nil
    
    let boxes = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let toWho = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    
    let labelAlice = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelBob = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelJohnny = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelJane = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelEve = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelTrent = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    let labelMallory = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
    
    var fY = CGFloat(10.0*9.8*30)       // Force on Y-axis
    var fX = CGFloat(0.0)               // Force on X-axis
    var pos = CGPoint(x: 0.0, y: 0.0)   // Position of drone body
    var pL = CGPoint(x: 0.0, y: 0.0)    // Position of left rotor
    var pR = CGPoint(x: 0.0, y: 0.0)    // Position of right rotor
    var vL = CGVector(dx: 0.0, dy: 0.0) // Velocity of left rotor
    var vR = CGVector(dx: 0.0, dy: 0.0) // Velocity of right rotor
    var rotation = CGFloat(0.0)         // In radian
    var inclination = CGFloat(0.0)      // In radian
    var sumOfAngle = CGFloat(0.0)       // In radian
    var backToNeutral = false
    
    // 30 pixels = 1 meter. SpriteKit default ratio 150 pixels = 1 meter. 30/150 = 1/5
    let ratio = 1.0/5.0
    
    let cameraNode = SKCameraNode()
    
    let zero = SKRange(constantValue: 0)
    let ninetyDegree = SKRange(constantValue: -CGFloat.pi/2)
    let positive90 = SKRange(constantValue: CGFloat.pi/2)
    
    // Time
    var t = 0.0
    var dt = 0.5
    var sinceKeyPressed = 0.0
    var afterLoad = 0.0
    
    var keyStroke: Int? = nil
    var multiplier = CGFloat(0.0)
    
    var start = true
    
    // Check if the box is delivered
    var delivered = true
    var deliveredToAlice = false
    var deliveredToTrent = false
    var deliveredToJohnny = false
    
    let ball = SKShapeNode(circleOfRadius: 10)
    
    public override func didMove(to view: SKView) {
        let background = childNode(withName: "background") as! SKSpriteNode
        background.physicsBody = SKPhysicsBody(edgeLoopFrom: background.frame)

        drone()
        cameraSetup()
        tower()
        labels()
        
        physicsWorld.contactDelegate = self
        
        arrow = childNode(withName: "arrow") as? SKSpriteNode
        if let a = arrow {
            a.alpha = 0.0
            a.setScale(0.6)
            a.position = CGPoint(x: 0, y: 0)
            let arrowLocation = SKConstraint.distance(zero, to: body)
            a.constraints = [arrowLocation]
        }
    }
    
    func load() {
        box = SKSpriteNode(imageNamed: "box")
        box.position = CGPoint(x: -188, y: -50)
        addChild(box)
        afterLoad = t
        let xBox = SKAction.move(by: CGVector(dx: 112+188, dy: 0), duration: 2)
        let yBox = SKAction.move(by: CGVector(dx: 0, dy: -75), duration: 1)
        let boxFadeOut = SKAction.fadeOut(withDuration: 1)
        let yGroup = SKAction.group([yBox, boxFadeOut])
        let motion = SKAction.sequence([xBox, yGroup])
        box.run(motion)
    }
    
    
    func drone() {
        body.position = CGPoint(x: 115, y: -92)
        body.anchorPoint = CGPoint(x: 0.47979798, y: 0.59574468)
        rotorL.anchorPoint = CGPoint(x: 0.207070, y: 0.8617)
        rotorR.anchorPoint = CGPoint(x: 0.752525, y: 0.8617)
        rotorL.position = CGPoint(x: body.frame.midX-29, y: body.frame.midY+17)
        rotorR.position = CGPoint(x: body.frame.midX+25, y: body.frame.midY+17)
        
        body.physicsBody = SKPhysicsBody(texture: body.texture!, size: body.texture!.size())
        rotorL.physicsBody = SKPhysicsBody(texture: rotorL.texture!, size: rotorL.texture!.size())
        rotorR.physicsBody = SKPhysicsBody(texture: rotorR.texture!, size: rotorR.texture!.size())
        
        body.physicsBody?.categoryBitMask = 0b0001
        rotorR.physicsBody?.categoryBitMask = 0b0010
        rotorL.physicsBody?.categoryBitMask = 0b0010
        body.physicsBody?.contactTestBitMask = 0b1000
        //rotorR.physicsBody?.contactTestBitMask = 0b1000
        //rotorL.physicsBody?.contactTestBitMask = 0b1000
        
        body.name = "drone"
        rotorL.name = "drone"
        rotorR.name = "drone"
        
        body.physicsBody?.mass = CGFloat(9.99999999*ratio)
        rotorL.physicsBody?.mass = CGFloat(0.00000005*ratio)
        rotorR.physicsBody?.mass = CGFloat(0.00000005*ratio)
        
        addChild(body)
        addChild(rotorR)
        addChild(rotorL)
        
        let jointL = SKPhysicsJointFixed.joint(withBodyA: body.physicsBody!, bodyB: rotorL.physicsBody!, anchor: body.anchorPoint)
        let jointR = SKPhysicsJointFixed.joint(withBodyA: body.physicsBody!, bodyB: rotorR.physicsBody!, anchor: body.anchorPoint)
        self.physicsWorld.add(jointL)
        self.physicsWorld.add(jointR)
        
        let locationR = SKConstraint.distance(zero, to: CGPoint(x: 27, y: 12), in: body)
        let locationL = SKConstraint.distance(zero, to: CGPoint(x: -27, y: 12), in: body)
        rotorR.constraints = [locationR]
        rotorL.constraints = [locationL]
        
        toWho.fontSize = 16
        toWho.fontColor = .darkGray
        toWho.position = CGPoint(x: 0, y: 20)
        toWho.text = ""
        body.addChild(toWho)
    }
    
    func cameraSetup() {
        camera = cameraNode
        addChild(cameraNode)
        let range = SKRange(lowerLimit: 0, upperLimit: 250)
        let constraint1 = SKConstraint.distance(range, to: body)
        let constranit2 = SKConstraint.positionY(SKRange(lowerLimit: -210, upperLimit: 210))
        let constraint3 = SKConstraint.positionX(SKRange(lowerLimit: -2500, upperLimit: 2500))
        cameraNode.constraints = [constraint1, constranit2, constraint3]
        
        boxes.text = "Boxes delivered: 0 / 3"
        boxes.fontSize = 22
        boxes.position = CGPoint(x: 280, y: 340)
        boxes.fontColor = .orange
        camera?.addChild(boxes)
    }
    
    func tower() {
        smallSignal.position = CGPoint(x: -2010, y: -285)
        midSignal.position = CGPoint(x: -2010, y: -285)
        largeSignal.position = CGPoint(x: -2010, y: -285)
        smallSignal.alpha = 0.0
        midSignal.alpha = 0.0
        largeSignal.alpha = 0.0
        let fadeInS = SKAction.fadeIn(withDuration: 0.5)
        let fadeOutS = SKAction.fadeOut(withDuration: 1.5)
        let fadeInM = SKAction.fadeIn(withDuration: 1.0)
        let fadeOutM = SKAction.fadeOut(withDuration: 1.0)
        let fadeInL = SKAction.fadeIn(withDuration: 1.5)
        let fadeOutL = SKAction.fadeOut(withDuration: 0.5)
        let sequenceS = SKAction.sequence([fadeInS, fadeOutS])
        let sequenceM = SKAction.sequence([fadeInM, fadeOutM])
        let sequenceL = SKAction.sequence([fadeInL, fadeOutL])
        smallSignal.run(.repeatForever(sequenceS))
        midSignal.run(.repeatForever(sequenceM))
        largeSignal.run(.repeatForever(sequenceL))
        
        addChild(smallSignal)
        addChild(midSignal)
        addChild(largeSignal)
    }
    
    func labels() {
        labelAlice.position = CGPoint(x: -2260, y: -220)
        labelEve.position = CGPoint(x: -1745, y: -250)
        labelTrent.position = CGPoint(x: -1470, y: -340)
        labelMallory.position = CGPoint(x: 1070, y: -215)
        labelJane.position = CGPoint(x: 1700, y: -300)
        labelJohnny.position = CGPoint(x: 2275, y: -300)
        labelBob.position = CGPoint(x: 2585, y: -300)
        labelAlice.text = "Alice"
        labelBob.text = "Bob"
        labelJohnny.text = "Johnny"
        labelJane.text = "Jane"
        labelMallory.text = "Malllory"
        labelEve.text = "Eve"
        labelTrent.text = "Trent"
        labelAlice.fontSize = 18
        labelBob.fontSize = 18
        labelEve.fontSize = 18
        labelJane.fontSize = 18
        labelJohnny.fontSize = 18
        labelMallory.fontSize = 18
        labelTrent.fontSize = 18
        addChild(labelAlice)
        addChild(labelBob)
        addChild(labelEve)
        addChild(labelJane)
        addChild(labelJohnny)
        addChild(labelMallory)
        addChild(labelTrent)
    }
    
    func force() {
        // When the drone is upside down, change force direction
        if rotation < -CGFloat.pi/2 && rotation > CGFloat.pi/2 {
            fY = -fY
        }
        body.physicsBody?.applyForce(CGVector(dx: fX, dy: fY))
        body.zRotation = inclination
    }
    
    func boxPhysicsBody() {
        box.physicsBody = SKPhysicsBody(texture: box.texture!, size: box.texture!.size())
        box.physicsBody?.linearDamping = 5
        box.physicsBody?.mass = CGFloat(2.0*ratio)
        if !deliveredToAlice {
            box.physicsBody?.categoryBitMask = 0x1 << 8
            box.physicsBody?.collisionBitMask = 0b11110111
            box.physicsBody?.contactTestBitMask = 0x1 << 3
        } else if !deliveredToTrent {
            box.physicsBody?.categoryBitMask = 0x1 << 9
            box.physicsBody?.collisionBitMask = 0b11101111
            box.physicsBody?.contactTestBitMask = 0x1 << 4
        } else {
            box.physicsBody?.categoryBitMask = 0x1 << 10
            box.physicsBody?.collisionBitMask = 0b11011111
            box.physicsBody?.contactTestBitMask = 0x1 << 5
        }
    }
  
    public override func mouseDown(with event: NSEvent) {
        //start = true
        
        let negative = SKAction.scaleX(to: -1.0, duration: 0.08)
        let positive = SKAction.scaleX(to: 1.0, duration: 0.08)
        let sequence1 = SKAction.sequence([negative, positive])
        let sequence2 = SKAction.sequence([positive, negative])
        
        // Two rotors need to spin in opposite direction to counter torque
        rotorL.run(.repeatForever(sequence1))
        rotorR.run(.repeatForever(sequence2))
    }
    
    public override func keyDown(with event: NSEvent) {
        backToNeutral = false
        if event.keyCode == 0 {
            fX -= 0.3*30
            keyStroke = 0
            sinceKeyPressed = t
        }
        if event.keyCode == 1 {
            fY -= 0.5*30
            keyStroke = 1
            sinceKeyPressed = t
        }
        if event.keyCode == 2 {
            fX += 0.3*30
            keyStroke = 2
            sinceKeyPressed = t
        }
        if event.keyCode == 13 {
            fY += 0.5*30
            keyStroke = 13
            sinceKeyPressed = t
        }
        if event.keyCode == 49 {
            box.run(SKAction.fadeIn(withDuration: 0.3))
            box.constraints = []
            boxPhysicsBody()
            boxes.text = "Empty"
        }
        if event.keyCode == 37 {
            if delivered {
                let Xbody = body.position.x
                let Ybody = body.position.y
                if Xbody > 75 && Xbody < 175 && Ybody < -60 && Ybody > -100 {
                    load()
                    body.physicsBody?.isDynamic = false
                } else {
                    print("out of loading range")
                }
            } else {
                print("deliver the current box before reloading!")
            }
        }
    }
    
    public override func keyUp(with event: NSEvent) {
        keyStroke = nil
        fY = CGFloat(10.0*9.8*30)
        fX = CGFloat(0.0)
        sinceKeyPressed = 0.0
        backToNeutral = true
    }
    
    
    public override func update(_ currentTime: TimeInterval) {
        t = currentTime
        if start {
            rotation = body.zRotation
            force()
            if sinceKeyPressed != 0.0 {
                if t-sinceKeyPressed > 0.1 {
                    multiplier = CGFloat(((t-sinceKeyPressed-0.1)/dt).rounded())
                    if keyStroke == 0 {
                        fX -= 0.1*30*multiplier
                        inclination = min(inclination+0.01*multiplier, CGFloat.pi/6)
                    }
                    if keyStroke == 1 {
                        fY -= 0.1*30*multiplier
                    }
                    if keyStroke == 2 {
                        fX += 0.1*30*multiplier
                        inclination = max(inclination-0.01*multiplier, -CGFloat.pi/6)
                    }
                    if keyStroke == 13 {
                        fY += 0.1*30*multiplier
                    }
                }
            }
            if backToNeutral {
                if inclination > 0 {
                    inclination = max(inclination-0.1, 0.0)
                }
                if inclination < 0 {
                    inclination = min(inclination+0.1, 0.0)
                }
            }
            if afterLoad != 0.0 {
                if t-afterLoad > 2 {
                    let constraint = SKConstraint.distance(zero, to: CGPoint(x: 0, y: -30), in: body)
                    box.constraints = [constraint]
                    delivered = false
                    afterLoad = 0.0
                    
                    body.physicsBody?.isDynamic = true
                    
                    if let a = arrow {
                        a.alpha = 1.0
                        if !deliveredToAlice {
                            toWho.text = "To: Alice  Loaded"
                            let arrowAngle = SKConstraint.orient(to: labelAlice, offset: positive90)
                            a.constraints?.append(arrowAngle)
                        } else if !deliveredToTrent {
                            toWho.text = "To: Trent  Loaded"
                            let arrowAngle = SKConstraint.orient(to: labelTrent, offset: positive90)
                            var _ = a.constraints?.popLast()
                            a.constraints?.append(arrowAngle)
                        } else {
                            toWho.text = "To: Johnny  Loaded"
                            let arrowAngle = SKConstraint.orient(to: labelJohnny, offset: positive90)
                            _ = a.constraints?.popLast()
                            a.constraints?.append(arrowAngle)
                        }
                    }
                }
            }
        }
    }
}

extension GameScene: SKPhysicsContactDelegate {
    func deliver() {
        let fade = SKAction.fadeOut(withDuration: 1)
        let fadeAndRemove = SKAction.sequence([fade, .removeFromParent()])
        box.run(fadeAndRemove)
        toWho.text = ""
    }
    public func didBegin(_ contact: SKPhysicsContact) {
        let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        if contactMask == 0b100001000 {
            delivered = true
            deliveredToAlice = true
            deliver()
            boxes.text = "Boxes Delivered: 1 / 3"
            if let a = arrow { a.alpha = 0.0 }
        }
        if contactMask == 0b1000010000 {
            delivered = true
            deliveredToTrent = true
            deliver()
            boxes.text = "Boxes Delivered: 2 / 3"
            if let a = arrow { a.alpha = 0.0 }
        }
        if contactMask == 0b10000100000 {
            delivered = true
            deliveredToJohnny = true
            deliver()
            boxes.text = "Boxes Delivered: 3 / 3"
            if let a = arrow { a.alpha = 0.0 }
            let congradulation = SKLabelNode(fontNamed: "ChalkboardSE-Bold")
            congradulation.text = "Congradulations!\nBoxes delivered: 3 / 3"
            congradulation.fontSize = 48
            congradulation.position = CGPoint(x: frame.midX, y: frame.midY)
            camera?.addChild(congradulation)
            self.run(SKAction.playSoundFileNamed("tada.aif", waitForCompletion: false))
        }
        
        if contact.collisionImpulse > 50 {
            if contact.bodyA.node?.name == "drone" || contact.bodyB.node?.name == "drone" {
                if contact.bodyA.node?.name == "signalTower" || contact.bodyB.node?.name == "signalTower" {
                    self.run(SKAction.playSoundFileNamed("ding.aif", waitForCompletion: false))
                } else {
                    self.run(SKAction.playSoundFileNamed("hitting.aif", waitForCompletion: false))
                }
            }
        }
    }
}
