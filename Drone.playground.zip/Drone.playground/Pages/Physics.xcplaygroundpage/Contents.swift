//: [Previous](@previous)
//:# Physics
//:
//: If FL > FR, it will start to rotate
//:
//: Let's see it in action in the liveview.
//:
//: Click the run button below, the little triangle
//:
//: open Asistant Editor
//:
//: Click the window to run
//:
import PlaygroundSupport
import SpriteKit

//: Let us start by looking at the forces that affect a drone.
//: Enter the mass of the drone in kilogram
let mass = 10.0
//: Enter the lift on each rotor in newton

var lift_of_the_left_rotor = 49.0
var lift_of_the_right_rotor = 48.5

let time_after_initial_state_0 = 0.5
let time_after_initial_state_1 = 1.0
let time_after_initial_state_2 = 2.5


let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 480))
//let scene = Physics(size: CGSize(width: 6000, height: 1200))
if let scene = Physics(fileNamed: "PhysicsBackground"){

    scene.mass = mass
    scene.fL = CGFloat(lift_of_the_left_rotor*30)
    scene.fR = CGFloat(lift_of_the_right_rotor*30)
    scene.duration = time_after_initial_state_2

    scene.scaleMode = .aspectFill

    sceneView.showsFPS = true
    sceneView.showsNodeCount = true
    sceneView.presentScene(scene)
}
PlaygroundPage.current.liveView = sceneView

//: [Next](@next)
