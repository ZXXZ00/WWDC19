//:# Introduction
//: Have you ever flied a drone before? Flying a drone does not seems hard——you just move the joysticks and the drone follows your instructions smoothly. But do you wonder about the physics calculation behind flying a drone?
//:
//: In this Playground we will explore some simple physics that makes flying a drone possible. Swift Playground is a very intuivitive way of learning. It can help learners to visualize, turning tedious textbooks and colorless lectures into lively examples. There is a game at the end of this Playground to help you better understand concepts like force, accelartion, velocity, lift, angular accelartion, etc.
/*:
 ### Tables of Contents
1. [Physics](Physics)
 
2. [Game_Easy](Game_Easy)
 
3. [Game_Hard](Game_Hard)
 
*/
//:
//: [Next](@next)
